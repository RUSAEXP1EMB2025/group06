//
//  ContentView.swift
//  LineGPSApp
//
//  Created by 細見風太 on 2025/05/14.
//

import SwiftUI
import LineSDK

struct ContentView: View {
    @State private var userID = ""
    @StateObject private var locationManager = LocationManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("ユーザーID: \(userID)")
            Text("現在地: \(locationManager.locationString)")
            
            Button("LINEログイン") {
                LoginManager.shared.login(permissions: [.profile]) { result in
                    switch result {
                    case .success(let loginResult):
                        if let profile = loginResult.userProfile {
                            print("ログイン成功: \(profile.userID)")
                            self.userID = profile.userID
                        } else {
                            self.userID = "取得失敗"
                        }
                    case .failure(let error):
                        print("ログイン失敗: \(error)")
                    }
                }


            }
            
            Button("現在地を送信") {
                sendLocationToSheet()
            }
        }
        .padding()
    }
    
    func sendLocationToSheet() {
        guard !userID.isEmpty else { return }
        let url = URL(string: "https://script.google.com/macros/s/AKfycbzzqsjRrTGpkeZQy-hiOdnqV4Ypn4nzewrQPbRaqWHgE_HwglBrI9_P-cPNu1mJzjvZ/exec")! // ← あなたのGAS URL
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let json: [String: String] = [
            "userId": userID,
            "location": locationManager.locationString
        ]
        
        request.httpBody = try? JSONSerialization.data(withJSONObject: json)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        URLSession.shared.dataTask(with: request) { _, response, error in
            if let error = error {
                print("送信失敗: \(error)")
            } else {
                print("送信成功")
            }
        }.resume()
    }
}
