//
//  AppDelegate.swift
//  LineGPSApp
//
//  Created by 細見風太 on 2025/05/14.
//

import UIKit
import LineSDK

class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        LoginManager.shared.setup(channelID: "2007347243", universalLinkURL: nil)
        return true
    }

    func application(
        _ app: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey : Any] = [:]
    ) -> Bool {
        return LoginManager.shared.application(app, open: url, options: options)
    }
}
