//
//  LineGPSAppApp.swift
//  LineGPSApp
//
//  Created by 細見風太 on 2025/05/14.
//

import SwiftUI
import LineSDK

@main
struct LineGPSApp: App {

    // AppDelegateを統合する
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView() // ← ここはあなたの最初の画面の名前（たとえば MainView や LoginView）に置き換える
        }
    }
}

