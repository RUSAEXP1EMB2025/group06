//
//  LocationManager.swift
//  LineGPSApp
//
//  Created by 細見風太 on 2025/05/14.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    @Published var locationString: String = "取得中..."
    
    override init() {
        super.init()
        manager.delegate = self
        manager.requestAlwaysAuthorization()  // ← ここが重要！
        manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            locationString = "\(lat),\(lon)"
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("位置情報エラー: \(error.localizedDescription)")
    }
}

