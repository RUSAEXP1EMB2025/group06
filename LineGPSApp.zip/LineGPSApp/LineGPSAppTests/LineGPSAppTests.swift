//
//  LineGPSAppTests.swift
//  LineGPSAppTests
//
//  Created by 細見風太 on 2025/05/14.
//

import Testing
@testable import LineGPSApp

struct LineGPSAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
